#!/usr/bin/env bash
# these get both gcc, make and python 
apt-get install -y python python-pip python-dev
apt-get update -y
apt install python-is-python3
apt-get install -y gdb
pip install -r /autograder/source/requirements.txt
